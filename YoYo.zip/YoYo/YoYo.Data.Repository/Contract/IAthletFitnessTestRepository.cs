﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using YoYo.Data.Entities;
using YoYo.Data.Model;

namespace YoYo.Data.Repository.Contract
{
    public interface IAthletFitnessTestRepository: IRepository<AthletFitnessTest>
    {
        Task<IEnumerable<AthletFitnessModel>> GetAllAthletFitnessAsync();
        Task DoWarningAsync(int athletId);
        Task UpdateResult(AthletFitnessResult athletFitnessResult);
    }
}
