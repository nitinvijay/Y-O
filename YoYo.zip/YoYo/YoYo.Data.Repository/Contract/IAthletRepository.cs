﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using YoYo.Data.Entities;
using YoYo.Data.Model;

namespace YoYo.Data.Repository.Contract
{
    public interface IAthletRepository : IRepository<Athlet>
    {
        Task<List<Athlet>> GetAllAthletAsync();
    }
}
