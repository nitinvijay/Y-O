﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YoYo.Data.Entities;
using YoYo.Data.Model;
using YoYo.Data.Repository.Contract;

namespace YoYo.Data.Repository
{
    public class AthletFitnessTestRepository : EfRepository<AthletFitnessTest>, IAthletFitnessTestRepository
    {
        public AthletFitnessTestRepository(YoYoDBContext context) : base(context) { }

        public Task<IEnumerable<AthletFitnessModel>> GetAllAthletFitnessAsync()
        {
            var athletFitnessTests = StaticData.athletFitnessTests;
            var athlets = StaticData.athlets;

            return Task.Run(() => athletFitnessTests.Join(athlets,
                                   af => af.AthletId,
                                   a => a.Id,
                                   (af, a) => new AthletFitnessModel()
                                   {
                                       FirstName = a.FirstName,
                                       LastName = a.LastName,
                                       IsStopped = af.IsStopped,
                                       IsWarned = af.IsWarned,
                                       ShuttleNo = af.ShuttleNo,
                                       SpeedLevel = af.SpeedLevel
                                   })
                );
        }

        public Task DoWarningAsync(int athletId)
        {
            return Task.Run(() => StaticData.athletFitnessTests.Where(w => w.AthletId == athletId).FirstOrDefault().IsWarned = true);
        }

        public Task UpdateResult(AthletFitnessResult athletFitnessResult)
        {
            return Task.Run(() => StaticData.athletFitnessResults.Where(w => w.TestId == athletFitnessResult.TestId).FirstOrDefault().Result = athletFitnessResult.Result);
        }
    }
}
