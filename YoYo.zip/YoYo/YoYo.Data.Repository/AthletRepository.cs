﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YoYo.Data.Entities;
using YoYo.Data.Repository.Contract;

namespace YoYo.Data.Repository
{
    public class AthletRepository: EfRepository<Athlet>, IAthletRepository
    {
        public AthletRepository(YoYoDBContext context) : base(context) { }

        public Task<List<Athlet>> GetAllAthletAsync()
        {
            var athlets = StaticData.athlets;
            return Task.Run(() => athlets.ToList());
        }

    }
}
