﻿using System;
using System.Collections.Generic;
using System.Text;
using YoYo.Data.Entities;

namespace YoYo.Data
{
    public class StaticData
    {
        public static List<Athlet> athlets = new List<Athlet>()
        {
            new Athlet() {Id = 1, FirstName = "Aston", LastName = "Eaton", Age = 20 },
            new Athlet() {Id = 2, FirstName = "Bryan", LastName = "Clay", Age = 21 },
            new Athlet() {Id = 3, FirstName = "Dean", LastName = "Karnazes", Age = 21 },
            new Athlet() {Id = 4, FirstName = "Usain", LastName = "Bolt", Age = 22}
        };

        public static List<AthletFitnessTest> athletFitnessTests = new List<AthletFitnessTest>()
        {
            new AthletFitnessTest() { Id = 1, AthletId = 1, IsStopped =false, IsWarned = false, ShuttleNo = 0, SpeedLevel = 1 },
            new AthletFitnessTest() { Id = 2, AthletId = 2, IsStopped =false, IsWarned = false, ShuttleNo = 0, SpeedLevel = 1 },
            new AthletFitnessTest() { Id = 3, AthletId = 3, IsStopped =false, IsWarned = false, ShuttleNo = 0, SpeedLevel = 1 },
            new AthletFitnessTest() { Id = 4, AthletId = 4, IsStopped =false, IsWarned = false, ShuttleNo = 0, SpeedLevel = 1 }
        };

        public static List<AthletFitnessResult> athletFitnessResults = new List<AthletFitnessResult>()
        {
            new AthletFitnessResult() {Id = 1, Result = "" },
            new AthletFitnessResult() {Id = 2, Result = "" },
            new AthletFitnessResult() {Id = 3, Result = "" },
            new AthletFitnessResult() {Id = 4, Result = "" },
        };
    }
}
