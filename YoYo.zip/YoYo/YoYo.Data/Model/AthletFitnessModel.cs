﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYo.Data.Model
{
    public class AthletFitnessModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool IsWarned { get; set; }
        public bool IsStopped { get; set; }
        public int SpeedLevel { get; set; }
        public int ShuttleNo { get; set; }
    }
}
