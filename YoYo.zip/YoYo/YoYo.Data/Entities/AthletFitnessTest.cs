﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYo.Data.Entities
{
    public partial class AthletFitnessTest: BaseEntity
    {
        public int AthletId { get; set; }
        public bool IsWarned { get; set; }
        public bool IsStopped { get; set; }
        public int SpeedLevel { get; set; }
        public int ShuttleNo { get; set; }
    }
}
