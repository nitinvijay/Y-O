﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYo.Data.Entities
{
    public class AthletFitnessResult: BaseEntity
    {
        public int TestId { get; set; }
        public string Result { get; set; }
    }
}
