﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using YoYo.Data.Entities;

namespace YoYo.Data
{
    public partial class YoYoDBContext : DbContext
    {
        public YoYoDBContext()
        {
        }

        public YoYoDBContext(DbContextOptions<YoYoDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<FitnessRating> FitnessRating { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "3.1.0-servicing-10034");


        }

    }
}
