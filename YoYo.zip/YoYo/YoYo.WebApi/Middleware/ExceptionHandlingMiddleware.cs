﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace YoYo.WebApi.Middleware
{
    public class ExceptionHandlingMiddleWare
    {
        private readonly RequestDelegate next;
        private readonly ILogger _logger;

        public ExceptionHandlingMiddleWare(RequestDelegate next, ILogger<ExceptionHandlingMiddleWare> logger)
        {
            this.next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
            finally
            {
                _logger.LogInformation(
                    "Request {method} {url} {request} => {statusCode}",
                    context.Request?.Method,
                    context.Request?.Path.Value,
                    context.Request.Body,
                    context.Response?.StatusCode);
            }
        }

        private Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            var ex = new
            {
                StatusCode = 500,
                Message = exception.Message
            };

            _logger.LogError(
                   "Request {method} {url} => {statusCode} {error} {stackTrace}",
                   context.Request?.Method,
                   context.Request?.Path.Value,
                   context.Response?.StatusCode,
                   exception.Message,
                   exception.StackTrace
                   );

            return context.Response.WriteAsync(exception.Message);
        }
    }
}
