﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using YoYo.Data.Entities;
using YoYo.Data.Repository.Contract;

namespace YoYo.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AthletFitnessTestController : ControllerBase
    {
        private readonly IAthletFitnessTestRepository repository;
        public AthletFitnessTestController(IAthletFitnessTestRepository athletFitnessTestRepository)
        {
            repository = athletFitnessTestRepository;
        }

        [HttpGet("FitnessRating")]
        public async Task<ActionResult<IEnumerable<FitnessRating>>> Get()
        {
            var fitnessRatingsJson = System.IO.File.ReadAllText(Path.Combine(Directory.GetCurrentDirectory(), "fitnessrating_beeptest.json"));

            IList<FitnessRating> fitnessRatings = JsonConvert.DeserializeObject<IList<FitnessRating>>(fitnessRatingsJson);


            if (fitnessRatings == null)
            {
                return NotFound("Fitness Ratings not found");
            }

            return await Task.Run(() => { 
                return Ok(fitnessRatings); 
            });
        }

        [HttpPut("Warning/{athletId}")]
        public async Task Warning(
        [Required(AllowEmptyStrings = false, ErrorMessage = "AthletId is required and can't empty.")]
            int athletId)
        {
            await repository.DoWarningAsync(athletId);
        }

        [HttpPost("Result")]
        public async Task PostResult([FromBody]AthletFitnessResult athletFitnessResult)
        {
            await repository.UpdateResult(athletFitnessResult);
        }

    }
}
