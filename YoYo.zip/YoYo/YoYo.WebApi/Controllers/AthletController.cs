﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using YoYo.Data.Entities;
using YoYo.Data.Repository.Contract;

namespace YoYo.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AthletController : ControllerBase
    {
        private readonly IAthletRepository repository;
        public AthletController(IAthletRepository athletRepository)
        {
            repository = athletRepository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Athlet>>> Get()
        {
            var athlets = await repository.GetAllAthletAsync();
            if (athlets == null)
            {
                return NotFound("Athlets not found");
            }

            return await Task.Run(() => { 
                return Ok(athlets); 
            });
        }
    }
}
